clc; clear all; close all; 


%% Chosen data: Housing

%% Using readtable to load the data

% Specify column names and types
opts.VariableNames = {'longitude', 'latitude', 'housing_median_age', 'total_rooms', ...
                      'total_bedrooms', 'population', 'households', ...
                      'median_income', 'median_house_value', 'ocean_proximity'}; 
opts.VariableTypes = repmat("double", 1, length(opts.VariableNames));

data = readtable("housing.csv");
[rows columns] = size(data);

opts = delimitedTextImportOptions("NumVariables", 11);

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

%Divide the data into calibration and test data 

% Set the seed for reproducibility
rng(10);

% Define the proportion of data for calibration
calibration_Proportion = 0.7;

% Create a random partition
c = cvpartition(rows, 'HoldOut', 1 - calibration_Proportion);

% Indices for training and testing sets
calibrationIdx = training(c);
testIdx = ~calibrationIdx;

% Divide the data Xcalib for calibration and Xtest for test
Xcalib = data(calibrationIdx, :);
Xtest = data(testIdx, :);

%% Pretreat the data delete missing values, clean, center

% Normalization
[df_treated1 yCal col_names] = pretreatment(Xcalib);
[XCal, muCal, sigmaCal] = zscore(df_treated1); %normalization calibration data
[yCalscaled, ymuCal, ysigmaCal] = zscore(yCal); %normalization of test data

% Apply the calibration center and standard deviation to the validation
% partition
[df_treated yVal col_names] = pretreatment(Xtest);
XVal = normalize(df_treated, 'Center', muCal, 'Scale', sigmaCal);
yValscaled = normalize(yVal, 'Center', ymuCal, 'Scale', ysigmaCal);

%%Calibration of PCR and PLS

% PCA
[PCALoadings, PCAScores,PCAlatent,PCAtsq, PCAVar] = pca(XCal,'Economy', false);

% PLS
[Xload, yload, XScore, YScore, betaPLS, PLSVar, PLSMSE, stats] = plsregress(XCal,yCalscaled,8,"cv",5);

%% Compare PCR AND PLS

% Visualize explained variance for both PCR and PLS
figure;
a = plot(1:8, 100*cumsum(PCAVar(1:8))/sum(PCAVar(1:8)),'-bo');
hold on
b = plot(1:8, 100*cumsum(PLSVar(1,:))/sum(PLSVar(1,:)),'-ro');
c = plot(1:8, 100*cumsum(PLSVar(2,:))/sum(PLSVar(2,:)),'-ko');
xlabel('No. components');
ylabel('Explained variables');
legend([a,b,c],{'PCR: Explained Variance in X','PLS: Explained Variance in X','PLS: Explained Variance in Y'});
title('Explained Var. Curve');
%At PC 4 (96% of the informations are retained), at PC 5 (99%).





% Error Q^2 plot for PCR and PLS.

% For PCR
betaPCR = regress(yCalscaled, PCAScores(:,1:5));%PCR
% Transform Beta from PCs to Beta Coefficients to actual values
betaPCR = PCALoadings(:,1:5)*betaPCR;
betaPCR = [mean(yCalscaled - mean(XCal)*betaPCR); betaPCR];
yfitPCR = [ones(size(XCal,1),1) XCal]*betaPCR;

% For PLS
yfitPLS = [ones(size(XCal,1),1) XCal]*betaPLS;

TSS = sum((yCalscaled).^2);
RSS_PLS = sum((yCalscaled - yfitPLS).^2);
RSS_PCR = sum((yCalscaled - yfitPCR).^2);

RsquaredPCR = 1-(RSS_PCR/TSS);
RsquaredPLS = 1-(RSS_PLS/TSS);

display(['Q2 for PCR is : ',num2str(RsquaredPCR)]);
display(['Q2 for PLS is : ',num2str(RsquaredPLS)]);
%RsquaredPCR (53.96%)
%RsquaredPLS (62.84%)



%% Calculate MSE for Test Partition
% Predictions for Test Set
yfitPCR_test = [ones(size(XVal, 1), 1), XVal] * betaPCR;
yfitPLS_test = [ones(size(XVal, 1), 1), XVal] * betaPLS;

% Calculate MSE
MSE_PCR = mean((yValscaled - yfitPCR_test).^2);
MSE_PLS = mean((yValscaled - yfitPLS_test).^2);

% Display MSE
fprintf('MSE for PCR on Test Set: %.4f\n', MSE_PCR);
fprintf('MSE for PLS on Test Set: %.4f\n', MSE_PLS);


%% Determine Number of Variables should be used from(MSE and Q^2).
%PC = 5 

% PCR with No. PCs 5.
PCRmsep = sum(crossval(@pcrsse, XCal, yCalscaled,'KFold',4),1)/rows; % number 4 means number of validations

% PLS with No. PCs 5.
[Xload, yload, XScore, YScore, betaPLS, PLSVar, PLSMSE, stats] = plsregress(XCal,yCalscaled,5,"cv",6);

% Error MSE plot for PCR and PLS.
figure;
a = plot(1:5,PCRmsep(1:5),'b-o');
hold on
b = plot(1:6, PLSMSE(1,:),'r-o');
c = plot(1:6, PLSMSE(2,:),'k-o');
xlabel('No. components');
ylabel('Estimated MSE');
title('Mean Squared Error Curve');
% legend([b,c],{'PLS: MSE in X','PLS: MSE in Y'});
legend([a,b,c],{'PCR: MSE in X','PLS: MSE in X','PLS: MSE in Y'});
% Ans : 5 PCs are good for the models.



%%Using bar plots of the regression coefficients (both for PLS and PCR),

figure;
betas = [betaPLS(2:end), betaPCR(2:end)];
bar(betas);
legend(["PLS Regression Coefficients", "PCR Regression Coefficients"]);
title("Bar Plots for Betas PLS & PCR Regression. Coeff.");
xticklabels(col_names);

%% Interpret a PLS triplot with X-side weights(W), Y-side loadings(Q), and x-side scores (T) (or alternatively T, P, Q).


%%Encountered error 

%%%%

nPCs_PLS = 6;%%PLS
nPCs_PCR = 4;%%PCR
MSE_Q2(XCal, yCalscaled, PCALoadings, PCAScores, nPCs_PLS);
MSE_Q2(XCal, yCalscaled, PCALoadings, PCAScores, nPCs_PCR);

%Q2 precision increased.


%% Calibrate PLS and PCR models with the most important variables in prediction selected at the previous step 
nPCs = 6;
[varResidual ypredPLS ypredPCR] = predict(XCal,XVal, yCalscaled, yValscaled, PCALoadings, PCAScores, nPCs);
%The model has a better level of performance.

%Plot the true values and the predicted values against each other

figure
scatter(1:length(yValscaled),  yValscaled, 'cyan', 'filled');
hold on
scatter(1:length(yValscaled),  ypredPLS, 'red');
scatter(1:length(yValscaled),  ypredPCR, 'green');
title("Predicted Vs True Value");
legend('True value','predicted-PLS','predicted-PCR');

% Ploting the Residual values PLS 

figure
Eobs = sum(varResidual.Xresiduals, 2);
EobsY = varResidual.Yresiduals;
scatter(1:length(Eobs),  Eobs, 'cyan', 'filled');
hold on
scatter(1:length(EobsY),  EobsY, 'red');
title("Observatons Residuals for the PLS model");
legend('X-residual','Y-residual');



%% Plotting Resifuals of PCR
% Ploting the Residual values PLS 

figure
Eobs = sum(varResidual.Xresiduals, 2);
EobsY = varResidual.Yresiduals;
scatter(1:length(Eobs),  Eobs, 'blue', 'filled');
hold on
scatter(1:length(EobsY),  EobsY, 'green');
title("Observatons Residuals for the PCR model");
legend('X-residual','Y-residual');



%% Function pretreatment
function [df y col_names] = pretreatment(data)

    data_clean = rmmissing(data);
    y = data_clean.median_house_value;
    data_clean = removevars(data_clean, {'median_house_value','ocean_proximity'});
    col_names = data_clean.Properties.VariableNames;
    df = table2array(data_clean);

end



function MSE_Q2(XCal, yCalscaled, PCALoadings, PCAScores, nPCs)
    
    % PCRmsep = sum(crossval(@pcrsse, XCal, yCalscaled,'KFold',4),1)/rows; % number 4 means number of validations

    % For PLS
    [Xload, yload, XScore, YScore, betaPLS, PLSVar, PLSMSE, stats] = plsregress(XCal,yCalscaled,nPCs,"cv",6);
    yfitPLS = [ones(size(XCal,1),1) XCal]*betaPLS;

    %Plots
    figure;
    % a = plot(1:5,PCRmsep(1:5),'b-o');
    hold on
    b = plot(1:nPCs, PLSMSE(1,1:nPCs),'r-o');
    c = plot(1:nPCs, PLSMSE(2,1:nPCs),'k-o');
    xlabel('No. components');
    ylabel('Estimated MSE');
    title(['MSE Curve for No. PCs = ',num2str(nPCs)]);
    legend([b,c],{'PLS: MSE in X','PLS: MSE in Y'});
    % legend([a,b,c],{'PCR: MSE in X','PLS: MSE in X','PLS: MSE in Y'});
    % Ans : 5 PCs are good for the models.
    
    % Error Q^2 plot for PCR and PLS.
    
    % For PCR
    betaPCR = regress(yCalscaled, PCAScores(:,1:nPCs));%PCR
    % Transform Beta from PCs to Beta Coefficients to actual values
    betaPCR = PCALoadings(:,[1:nPCs])*betaPCR;
    betaPCR = [mean(yCalscaled - mean(XCal)*betaPCR); betaPCR];
    yfitPCR = [ones(size(XCal,1),1) XCal]*betaPCR;
    
    TSS = sum((yCalscaled).^2);
    RSS_PLS = sum((yCalscaled - yfitPLS).^2);
    RSS_PCR = sum((yCalscaled - yfitPCR).^2);
    
    RsquaredPCR = 1-(RSS_PCR/TSS);
    RsquaredPLS = 1-(RSS_PLS/TSS);

    display(['Q2 indicatior after selection the number PCs.']);    
    display(['No. PCs = ',num2str(nPCs),' with Q2 PCR : ',num2str(RsquaredPCR)]);
    display(['No. PCs = ',num2str(nPCs),' with Q2 PLS : ',num2str(RsquaredPLS)]);

end

function [Residual yPLS yPCR] = predict(XCal,XVal, yCalscaled, yValscaled, PCALoadings, PCAScores, nPCs)
    
    % PCRmsep = sum(crossval(@pcrsse, XCal, yCalscaled,'KFold',4),1)/rows; % number 4 means number of validations

    % For PLS
    [Xload, yload, XScore, YScore, betaPLS, PLSVar, PLSMSE, stats] = plsregress(XCal,yCalscaled,nPCs,"cv",6);
    yfitPLS = [ones(size(XVal,1),1) XVal]*betaPLS;

    % Error Q^2 plot for PCR and PLS.
    
    % For PCR
    betaPCR = regress(yCalscaled, PCAScores(:,1:nPCs));%PCR
    % Transform Beta from PCs to Beta Coefficients to actual values
    betaPCR = PCALoadings(:,[1:nPCs])*betaPCR;
    betaPCR = [mean(yCalscaled - mean(XCal)*betaPCR); betaPCR];
    yfitPCR = [ones(size(XVal,1),1) XVal]*betaPCR;
    
    %Error
    TSS = sum((yValscaled).^2);
    RSS_PLS = sum((yValscaled - yfitPLS).^2);
    RSS_PCR = sum((yValscaled - yfitPCR).^2);
    
    RsquaredPCR = 1-(RSS_PCR/TSS);
    RsquaredPLS = 1-(RSS_PLS/TSS);
    
    display(['Q2 indicatior after using validation data']);
    display(['No. PCs = ',num2str(nPCs),' with Q2 PCR : ',num2str(RsquaredPCR)]);
    display(['No. PCs = ',num2str(nPCs),' with Q2 PLS : ',num2str(RsquaredPLS)]);
    Residual = stats;
    yPLS = yfitPLS;
    yPCR = yfitPCR;
end

